class Config:
    MONGO_URI = 'mongodb+srv://souvik:Souvik8918@cluster0.hypqczx.mongodb.net/faqs?retryWrites=true&w=majority&appName=Cluster0'
